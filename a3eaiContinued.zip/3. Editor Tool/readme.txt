 Installing the A3EAI Editor Tool

1. Open your ArmA 3 client and open the Editor.

2. Select the map you want to work with and press Continue.

3. Double-click anywhere on the map to place a unit. Do not change any settings. Press OK to place the unit.

4. Save this mission in the Editor by pressing CTRL+S.

5. Save your mission with a mission name of your choice. Remember this name.

6. Locate your downloaded A3EAI install package. Locate the init.sqf file contained within the Editor Tool folder. Right click on this file and select Copy.

7. Locate your ArmA 3 client mission folder.

        Windows 7/8/10: C:\My Documents\Arma 3 - Other Profiles\[ArmA3 Profile Name]\missions

8. Find and open the folder that contains the name you assigned in Step 6.

9. Paste the init.sqf file inside this folder.


For more details on using the Editor Tool, visit the A3EAI Wikia site here: http://a3eai.wikia.com/wiki/A3EAI_Editor_Tool